import websockify

if __name__ == '__main__':
    websockify.websocketproxy.websockify_init()
